package sokoban;

public class Jatek {

	void StartGame() {
		System.out.println("Jatek"+'\t'+"StartGame()");
	}
	
	void EndGame() {
		System.out.println("Jatek"+'\t'+"EndGame()");
	}
	
}
