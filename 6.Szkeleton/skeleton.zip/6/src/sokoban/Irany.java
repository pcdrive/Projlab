package sokoban;

public enum Irany {
Fel,
Le,
Jobbra,
Balra
}
