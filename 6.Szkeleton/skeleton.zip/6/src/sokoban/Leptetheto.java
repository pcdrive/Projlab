package sokoban;

public abstract class Leptetheto {

	protected UresMezo mezo;
	protected Palya palya;
	
	public abstract  boolean Utkozik(Irany i, Jatekos j);
	
	public abstract boolean Tol(Irany i, Jatekos j);
	
	public abstract void Halal();
	
}
