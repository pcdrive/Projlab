package sokoban;

public class Main {

	public static void main(String[] args) {
		Jatek j = new Jatek();
		j.StartGame();
	}

}
