package data;

public class Data {
//    public static final int JatekosEro = 1;
    public static int PalyaX = 5;
    public static int PalyaY = 5;
}
